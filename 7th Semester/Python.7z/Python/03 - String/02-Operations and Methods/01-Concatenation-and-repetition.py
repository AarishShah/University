# Program to demonstrate String operations

str1 = "Seventh"
str2 = "Semester"

print(str1 + str2) # Concatenation
print(str1 * 3) # Repetition
print(3 * str1) # Repetition