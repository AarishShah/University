# Program to demonstrate if statement

# a = 4
a = 10

if (a > 5):
    print("a is greater than 5")
    print("Completed if")
else:
    print("a is not greater than 5")
    print("Completed else")