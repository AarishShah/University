# Program to demonstrate if-elif-else statement

a = 10

if (a > 5):
    print("a is greater than 5")
    print("Completed if")
elif (a > 7):
    print("a is greater than 7")
    print("Completed elif")
else:
    print("a is not greater than 5")