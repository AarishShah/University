# User-defined functions

def greet():
    print("Hello World!")
    print("Good Morning!")

greet()