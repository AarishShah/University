# Functions are of two types:
# 1. Built-in functions
# 2. User-defined functions

# Built-in functions
# print(), input(), len(), type(), range(), etc.

# User-defined functions
'''
 def function_name(parameters):
     statement1
     statement2
     ...
     statementN
     return value # optional

 def function_name(parameters):
'''