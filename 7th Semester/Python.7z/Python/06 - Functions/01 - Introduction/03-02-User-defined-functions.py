# User-defined functions
'''
def function_name(arg1, arg2, ... argN):
    statement1
    statement2
    ...
    statementN
    return value # optional
'''

def main():
    a = 2
    b = 10
    exp(a,b)

def exp(a,b):
    print(a**b)

main()
