
# Built-in functions

import math

x = 0.8
math.cos(x)
print(x)

r = 1
area = math.pi * r ** 2
print(area)