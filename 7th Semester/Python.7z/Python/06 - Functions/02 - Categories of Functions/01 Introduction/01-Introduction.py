# There are two typed of functions based on parameters:
# 1. Parameterised functions
# 2. Non-parameterised functions

# There are two typed of functions based on return type:
# 1. void functions
# 2. fruitful functions

# There are five types of functions on the basis of arguments:
# 1. Function with no arguments
# 2. Function with fixed arguments
# 3. Function with named arguments (keyword arguments)
# 4. Function with default arguments
# 5. Function with variable-length arguments