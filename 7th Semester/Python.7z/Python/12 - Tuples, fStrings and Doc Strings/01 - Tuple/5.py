Roll = (1, 2, 3, 4, 5, 6, 3, 4, 3, 3, 3)

# Roll.count(3)
print(Roll.count(3))  # Gives the count of 3 in the tuple

# tuple.index(value, start, stop)
# 3 is the value to be searched, 1 is the starting index and 7 is the ending index
print(Roll.index(3, 1, 7))

# len(tuple)
print(len(Roll))  # Gives the length of the tuple