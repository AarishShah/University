A = (1,2,3)
B = (4,5,6)
C = A + B

print(C) # (1, 2, 3, 4, 5, 6)

A = A + B
print(A) # (1, 2, 3, 4, 5, 6) - A is overwritten as new memory is allocated for A