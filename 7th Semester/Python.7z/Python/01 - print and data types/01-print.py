print(10)  # Integer
print("Python")  # String
print(10*3)  # Multiplication
print(10*"Python\n")  # String multiplication (Repetition operator)

'''
This is a multi-line comment
'''

# This is a single line comment

print(10)  # new line is added by default
print(20)

print("Welcome", 4, 32)  # Multiple arguments
print("Welcome", 4, 32, sep="~")  # Separator
print("Welcome", 4, 32, sep="~", end="*")  # End
