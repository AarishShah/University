d = {}

d['Khushboo'] = 100 # key is string and will store 100 as value
d[1] = 200 # key is integer and will store 200 as value
d["1"] = 300 # key is string and will store 300 as value

print(d)

