# For Loop

for i in range(10):
    print(i)

# will print 0-9 and not 1-10 