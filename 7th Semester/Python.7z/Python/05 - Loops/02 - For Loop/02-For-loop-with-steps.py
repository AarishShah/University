for i in range(1, 11, 2):  # 1 is the starting point, 11 is the ending point, 2 is the increment (also called step)
    print(i)

#  will print values from 1 to 10 with increment of 2