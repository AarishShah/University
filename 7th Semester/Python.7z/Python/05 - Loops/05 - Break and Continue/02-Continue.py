for i in range(10):
    if i == 5:
        continue  # Skip the rest of the code inside a loop for the current iteration
    print(i)
