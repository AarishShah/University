for i in range(10):  # equal to range(0,10)
    print(i)
    if (i > 5):
        break
    if (i == 4):
        continue
