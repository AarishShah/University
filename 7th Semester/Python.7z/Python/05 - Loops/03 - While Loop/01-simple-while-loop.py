# While Loop

a = 0
while (a < 3):
    print(a)
    a = a + 1

print("")

b = 10
while (b>5):
    print(b)
    b = b - 1
