a = int(input("Enter a number: "))
while a<5:
    print(a)
    a = int(input("Enter a number: "))
    print(a)

# A real-life example could be, "Do read at least one chapter of a book, and continue reading while it is interesting." In this case, you will read at least one chapter regardless of the book's interestingness. After the first chapter, you will continue reading more chapters only if you find the book interesting.