a = input("Enter a number: ")
b = input("Enter another number: ")
print(a + b) # String
print(int(a) + int(b)) # Number

c = int(input("Enter a number: "))
d = int(input("Enter another number: "))
print(c + d) # Number

e = input("")
print(e)