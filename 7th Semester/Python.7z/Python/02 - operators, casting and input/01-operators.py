# +, -, *, /, %, **, //

# Simple program to demonstrate arithmetic operators in Python

# Predefined values
num1 = 10
num2 = 3

# Perform arithmetic operations and display the results
print(f"Addition of {num1} and {num2}: {num1 + num2}")
print(f"Subtraction of {num2} from {num1}: {num1 - num2}")
print(f"Multiplication of {num1} and {num2}: {num1 * num2}")
print(f"Division of {num1} by {num2}: {num1 / num2}")
print(f"Modulus of {num1} and {num2}: {num1 % num2}")
print(f"Exponentiation of {num1} to the power of {num2}: {num1 ** num2}")
print(f"Floor division of {num1} by {num2}: {num1 // num2}")