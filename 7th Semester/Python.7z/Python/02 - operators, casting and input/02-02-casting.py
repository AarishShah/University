a = "7"
b = "6"

print(a + b) # 76 (string concatenation)
print(int(a) + int(b)) # 13 (integer addition)