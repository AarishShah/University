# Converts ASCII value to character

d = {}
for i in range(65, 65+26):
    d[i] = chr(i) # right side is value and left side is key

print(d)