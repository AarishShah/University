Khushboo = 'a', 'b', 'c'
print(Khushboo)
print(type(Khushboo)) #tuple

Humma = (1, 2, 3)
print(Humma)
print(type(Humma)) #tuple

Uzair = (10)
print(Uzair)
print(type(Uzair)) #int

Saood = (10,)
print(Saood)
print(type(Saood)) #tuple

Robo = ("Lily")
print(Robo)
print(type(Robo)) #str

Mustaffa = ("Lily",)
print(Mustaffa)
print(type(Mustaffa)) #tuple